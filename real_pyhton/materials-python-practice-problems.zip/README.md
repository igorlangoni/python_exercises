# Python Practice Problems

Unittest stubs for ["Python Practice Problems."](https://realpython.com/python-practice-problems/)

## Running the Tests

To run the test for a given problem, use `unittest` from the Python standard library;

```console
$ python -m unittest integersums.py
```

The above example will run the unit tests for the first practice problem.